// OnClick event to show and hide form while clicking on Register button
document.getElementById('myBtn').onclick = function(){
    let formDiv = document.getElementById('myModal');
    if(formDiv.style.display == 'block'){
        formDiv.style.display = 'none';
    }else{
        formDiv.style.display = 'block';
    }
}

// Adding data values to the form table
var list1 = [];
var list2 = [];
var list3 = [];
var list4 = [];
var list5 = [];
var list6 = [];
var list7 = [];
var list8 = [];
var list9 = [];
var list10 = [];
var list11 = [];
var list12 = [];

var n = 1;
var x = 0;

function addValues(){
    var addValuesn = document.getElementById('show');
    var newRow = addValuesn.insertRow(n);

    list1[x] = document.getElementById('fname').value;
    list2[x] = document.getElementById('lname').value;
    list3[x] = document.getElementById('aadharNo').value;
    list4[x] = document.getElementById('contactNo').value;
    list5[x] = document.getElementById('dob').value;
    list6[x] = document.getElementById('gendersel').value;
    list7[x] = document.getElementById('precheck').value;
    list8[x] = document.getElementById('covidsymptoms').value;
    list9[x] = document.getElementById('street').value;
    list10[x] = document.getElementById('landMark').value;
    list11[x] = document.getElementById('pcode').value;
    list12[x] = document.getElementById('state').value;

    var cel1 = newRow.insertCell(0);
    var cel2 = newRow.insertCell(1);
    var cel3 = newRow.insertCell(2);
    var cel4 = newRow.insertCell(3);
    var cel5 = newRow.insertCell(4);
    var cel6 = newRow.insertCell(5);
    var cel7 = newRow.insertCell(6);
    var cel8 = newRow.insertCell(7);
    var cel9 = newRow.insertCell(8);
    var cel10 = newRow.insertCell(9);
    var cel11 = newRow.insertCell(10);
    var cel12 = newRow.insertCell(11);

    cel1.innerHTML = list1[x];
    cel2.innerHTML = list2[x];
    cel3.innerHTML = list3[x];
    cel4.innerHTML = list4[x];
    cel5.innerHTML = list5[x];
    cel6.innerHTML = list6[x];
    cel7.innerHTML = list7[x];
    cel8.innerHTML = list8[x];
    cel9.innerHTML = list9[x];
    cel10.innerHTML = list10[x];
    cel11.innerHTML = list11[x];
    cel12.innerHTML = list12[x];

    n++;
    x++;
}


// To activate close (x) button in HTML form
var closebtns = document.getElementsByClassName('close');
var i;

for (i = 0; i < closebtns.length; i++) {
  closebtns[i].addEventListener("click", function() {
    this.parentElement.style.display = 'none';
  });
}

// Form submiting
// document.getElementById('btnSubmit').onclick = function(){
//     let submitBtn = document.getElementById('myModal');
//     if(submitBtn.style.display == 'none'){
//         submitBtn.style.display = 'block';
//     }else{
//         submitBtn.style.display = 'none';
//     }
// }